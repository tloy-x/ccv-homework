USAGE
The program can be run from UI (double clicked), or envoked in console/terminal.
UI running does not create an output file.

TERMINAL USAGE - Creates Output File
$ week9.exe

$ week9.exe [input file]

Included are a couple of test files which can be modified. This is the formatting for input.