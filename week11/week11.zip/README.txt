blackjack.cpp needs to be recompiled for your system before it can be used.

This is a terminal application, and it does not work when run from a GUI.

USAGE: $ ./blackjack
       blackjack.exe
